#!/usr/bin/env bash

#
python3 /Users/gusevdmi/projects/~gusevdmi/automation/autoscripts/gitupdate.py --pass $1 --javadoc --sources
